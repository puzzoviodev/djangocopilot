
from django.http import JsonResponse, Http404
from django.shortcuts import render
from django.template.loader import get_template
from .models import IndicatorRecord
import json

# ----------------------------
# API JSON: /api/dataset
# Retorna o shape: { "ativo_col": "Ativo", "data": [ {...} ] }
# ----------------------------

def dataset_json(request):
    qs = IndicatorRecord.objects.all()

    # Filtros simples por querystring (opcional)
    ind = request.GET.get('indicador')
    atv = request.GET.get('ativo')
    cls = request.GET.get('classificacao')
    if ind: qs = qs.filter(Indicador=ind)
    if atv: qs = qs.filter(Ativo=atv)
    if cls: qs = qs.filter(Classificacao=cls)

    # Limit para evitar payloads enormes
    limit = int(request.GET.get('limit') or 2000)
    qs = qs[:limit]

    # Seleciona apenas os campos usados no front
    data = list(qs.values(
        'Agrupador','Fonte','Ativo','Indicador','Formula','Definicao','Referencia',
        'Valor','Classificacao','Faixa','Descricao'
    ))
    return JsonResponse({ 'ativo_col': 'Ativo', 'data': data }, json_dumps_params={'ensure_ascii': False})

# ----------------------------
# Páginas dinâmicas (client-side fetch)
# Rota: /page/<name>/  -> templates/user_pages/<name>.html
# A página deve carregar o dataset via fetch (ex.: static/js/dataset-loader.js)
# ----------------------------

def page_by_name_fetch(request, name: str):
    template_path = f'user_pages/{name}.html'
    try:
        # Apenas verifica se o template existe; render sem contexto especial
        get_template(template_path)
    except Exception:
        raise Http404(f'Template {template_path} não encontrado.')
    return render(request, template_path, {})

# ----------------------------
# Páginas dinâmicas (SSR)
# Rota: /page-ssr/<name>/ -> injeta JSON no template, caso o HTML espere <script id="dataset">.
# No template, use: <script id="dataset" type="application/json">{{ dataset_json|safe }}</script>
# ----------------------------

def page_by_name_ssr(request, name: str):
    template_path = f'user_pages/{name}.html'
    try:
        get_template(template_path)
    except Exception:
        raise Http404(f'Template {template_path} não encontrado.')

    # Monta o JSON com os dados atuais
    qs = IndicatorRecord.objects.all()[:2000]
    data = list(qs.values(
        'Agrupador','Fonte','Ativo','Indicador','Formula','Definicao','Referencia',
        'Valor','Classificacao','Faixa','Descricao'
    ))
    ds = { 'ativo_col': 'Ativo', 'data': data }
    ds_str = json.dumps(ds, ensure_ascii=False)

    return render(request, template_path, { 'dataset_json': ds_str })
