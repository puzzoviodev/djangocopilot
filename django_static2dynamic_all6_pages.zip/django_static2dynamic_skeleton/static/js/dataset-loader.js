
// Carrega dataset da API e expõe em window.RAW + dispara window.initPage()
function loadDataset(url){
  fetch(url, {headers:{'Accept':'application/json'}})
    .then(r=>r.json())
    .then(json=>{
       window.AT = json.ativo_col || 'Ativo';
       window.RAW = json.data || [];
       if (typeof window.initPage === 'function') window.initPage();
    })
    .catch(err=>{
       console.error('Falha ao carregar dataset:', err);
       window.AT = 'Ativo';
       window.RAW = [];
       if (typeof window.initPage === 'function') window.initPage();
    });
}
