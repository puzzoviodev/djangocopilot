
// static/js/pages/hf01_togglecard.js

const CLASS_MAP = {
  'Ótimo':'otimo','Otimo':'otimo','Muito Bom':'muito-bom','Bom':'bom','Moderado':'moderado','Ruim':'ruim','Crítico':'critico','Critico':'critico','Muito Crítico':'muito-critico','Muito Critico':'muito-critico'
};
const PCT_INDICATORS = new Set(['ROIC','ROE','ROA','M. EBITDA','M. EBIT','M. Bruta','M. Liquida','D.Y','DY','Margem EBITDA','Margem EBIT','Margem Bruta','Margem Liquida']);
function fmtValor(rec){
  const v = rec.Valor; if(v===null||v===undefined||v==='') return '—';
  if (PCT_INDICATORS.has(rec.Indicador)) return (Number(v)*100).toFixed(2).replace('.', ',') + '%';
  const n = Number(v); if (Math.abs(n) >= 1000) return n.toLocaleString('pt-BR');
  let s = String(v); if (s.includes('.')) s = Number(v).toLocaleString('pt-BR', {maximumFractionDigits:4});
  return s;
}
function by(sel, el=document){ return el.querySelector(sel); }
function all(sel, el=document){ return Array.from(el.querySelectorAll(sel)); }

window.initPage = function(){
  const wrap = by('#grid');
  by('#resume').textContent = `Registros: ${RAW.length} · Colunas: 11`;
  const CLASSES = ['Ótimo','Muito Bom','Bom','Moderado','Ruim','Crítico','Muito Crítico','Todos'];
  const fbar = by('#filters');
  CLASSES.forEach(label=>{ const b=document.createElement('button'); b.className='btn'; b.textContent=label; b.dataset.label=label; fbar.appendChild(b); });
  fbar.addEventListener('click', ev=>{ const b=ev.target.closest('button'); if(!b) return; all('.filters .btn').forEach(x=>x.classList.remove('active')); b.classList.add('active'); render(b.dataset.label); });
  by('#q').addEventListener('input', ()=> render(currentFilter));
  let currentFilter = 'Todos';
  function render(filter='Todos'){
    currentFilter=filter; wrap.innerHTML=''; const q=by('#q').value.trim().toLowerCase();
    let data = RAW; if(filter!=='Todos') data = data.filter(r=>r.Classificacao===filter);
    if(q) data = data.filter(r=> (r.Indicador||'').toLowerCase().includes(q) || (r.Ativo||'').toLowerCase().includes(q));
    for(const rec of data){
      const chip=CLASS_MAP[rec.Classificacao]||'moderado';
      const card=document.createElement('div'); card.className='card';
      card.innerHTML = `
        <div class="meta">${rec.Ativo} · ${rec.Agrupador || '—'} · ${rec.Fonte || '—'}</div>
        <h3>${rec.Indicador} <span class="chip ${chip}">${rec.Classificacao}</span></h3>
        <div class="value">${fmtValor(rec)}</div>
        <div class="small">Clique no cartão para ver detalhes</div>
        <div class="details">
          <table>
            <tr><td><b>Agrupador</b></td><td>${rec.Agrupador||'—'}</td></tr>
            <tr><td><b>Fonte</b></td><td>${rec.Fonte||'—'}</td></tr>
            <tr><td><b>Fórmula</b></td><td>${rec.Formula||'—'}</td></tr>
            <tr><td><b>Definição</b></td><td>${rec.Definicao||'—'}</td></tr>
            <tr><td><b>Faixa</b></td><td>${rec.Faixa||'—'}</td></tr>
            <tr><td><b>Descrição</b></td><td>${rec.Descricao||'—'}</td></tr>
          </table>
        </div>`;
      card.addEventListener('click', (e)=>{ if(e.target.closest('a,button,input,select,textarea')) return; const det=card.querySelector('.details'); det.style.display = det.style.display==='block'?'none':'block'; });
      wrap.appendChild(card);
    }
  }
  render('Todos');
}
