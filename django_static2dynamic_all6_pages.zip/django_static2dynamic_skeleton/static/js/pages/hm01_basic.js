
// static/js/pages/hm01_basic.js

const CLASS_MAP = {
  'Ótimo':'otimo','Otimo':'otimo','Muito Bom':'muito-bom','Bom':'bom','Moderado':'moderado','Ruim':'ruim','Crítico':'critico','Critico':'critico','Muito Crítico':'muito-critico','Muito Critico':'muito-critico'
};
const PCT_INDICATORS = new Set(['ROIC','ROE','ROA','M. EBITDA','M. EBIT','M. Bruta','M. Liquida','D.Y','DY','Margem EBITDA','Margem EBIT','Margem Bruta','Margem Liquida']);
function fmtValor(rec){
  const v = rec.Valor; if(v===null||v===undefined||v==='') return '—';
  if (PCT_INDICATORS.has(rec.Indicador)) return (Number(v)*100).toFixed(2).replace('.', ',') + '%';
  const n = Number(v); if (Math.abs(n) >= 1000) return n.toLocaleString('pt-BR');
  let s = String(v); if (s.includes('.')) s = Number(v).toLocaleString('pt-BR', {maximumFractionDigits:4});
  return s;
}
function by(sel, el=document){ return el.querySelector(sel); }
function all(sel, el=document){ return Array.from(el.querySelectorAll(sel)); }

window.initPage = function(){
  const container = by('#grid');
  by('#resume').textContent = `Registros: ${RAW.length} · Colunas: 11`;
  const CLASSES=['Ótimo','Muito Bom','Bom','Moderado','Ruim','Crítico','Muito Crítico','Todos']; const fbar=by('#filters'); CLASSES.forEach(label=>{ const b=document.createElement('button'); b.className='btn'; b.textContent=label; b.dataset.label=label; fbar.appendChild(b); }); fbar.addEventListener('click', ev=>{ const b=ev.target.closest('button'); if(!b) return; all('.filters .btn').forEach(x=>x.classList.remove('active')); b.classList.add('active'); render(b.dataset.label); }); by('#q').addEventListener('input', ()=> render(currentFilter));
  const colorClass = c => CLASS_MAP[c] || 'moderado'; let currentFilter='Todos';
  function render(filter='Todos'){
    currentFilter=filter; container.innerHTML=''; const q=by('#q').value.trim().toLowerCase(); let data=RAW; if(filter!=='Todos') data=data.filter(r=>r.Classificacao===filter); if(q) data=data.filter(r=> (r.Indicador||'').toLowerCase().includes(q) || (r.Ativo||'').toLowerCase().includes(q));
    const byAtivo=new Map(); for(const r of data){ if(!byAtivo.has(r.Ativo)) byAtivo.set(r.Ativo, []); byAtivo.get(r.Ativo).push(r); }
    for(const [ativo, regs] of byAtivo){ const section=document.createElement('section'); section.innerHTML = `<h3 style="margin:8px 0 10px">${ativo}</h3>`; const grid=document.createElement('div'); grid.style.display='grid'; grid.style.gridTemplateColumns='repeat(auto-fill,minmax(120px,1fr))'; grid.style.gap='8px'; regs.sort((a,b)=> (a.Indicador||'').localeCompare(b.Indicador||'')); for(const rec of regs){ const tile=document.createElement('div'); tile.className='card'; tile.innerHTML = `<div class=small>${rec.Agrupador||'—'} · ${rec.Fonte||'—'}</div><div class=meta style="margin-top:4px">${rec.Indicador}</div><div class="chip ${colorClass(rec.Classificacao)}" style="margin-top:6px">${rec.Classificacao}</div><div class=value style="font-size:1.1rem;margin-top:6px">${fmtValor(rec)}</div>`; grid.appendChild(tile);} section.appendChild(grid); container.appendChild(section);} }
  render('Todos');
}
