
// static/js/pages/hf07_filter_quickstats.js

const CLASS_MAP = {
  'Ótimo':'otimo','Otimo':'otimo','Muito Bom':'muito-bom','Bom':'bom','Moderado':'moderado','Ruim':'ruim','Crítico':'critico','Critico':'critico','Muito Crítico':'muito-critico','Muito Critico':'muito-critico'
};
const PCT_INDICATORS = new Set(['ROIC','ROE','ROA','M. EBITDA','M. EBIT','M. Bruta','M. Liquida','D.Y','DY','Margem EBITDA','Margem EBIT','Margem Bruta','Margem Liquida']);
function fmtValor(rec){
  const v = rec.Valor; if(v===null||v===undefined||v==='') return '—';
  if (PCT_INDICATORS.has(rec.Indicador)) return (Number(v)*100).toFixed(2).replace('.', ',') + '%';
  const n = Number(v); if (Math.abs(n) >= 1000) return n.toLocaleString('pt-BR');
  let s = String(v); if (s.includes('.')) s = Number(v).toLocaleString('pt-BR', {maximumFractionDigits:4});
  return s;
}
function by(sel, el=document){ return el.querySelector(sel); }
function all(sel, el=document){ return Array.from(el.querySelectorAll(sel)); }

window.initPage = function(){
  const wrap = by('#grid');
  by('#resume').textContent = `Registros: ${RAW.length} · Colunas: 11`;
  const qsHost = document.createElement('div'); qsHost.className='quickstats'; by('.container').insertBefore(qsHost, by('#filters').nextSibling);
  const CLASSES = ['Ótimo','Muito Bom','Bom','Moderado','Ruim','Crítico','Muito Crítico','Todos'];
  const fbar = by('#filters'); CLASSES.forEach(label=>{ const b=document.createElement('button'); b.className='btn'; b.textContent=label; b.dataset.label=label; fbar.appendChild(b); });
  fbar.addEventListener('click', ev=>{ const b=ev.target.closest('button'); if(!b) return; all('.filters .btn').forEach(x=>x.classList.remove('active')); b.classList.add('active'); render(b.dataset.label); });
  by('#q').addEventListener('input', ()=> render(currentFilter));
  function statCard(k, v){ const el=document.createElement('div'); el.className='qs'; el.innerHTML=`<div class=k>${k}</div><div class=v>${v}</div>`; return el; }
  function recomputeQuickStats(data){
    qsHost.innerHTML=''; const total=data.length; const ativos=new Set(data.map(d=>d.Ativo)); const indic=new Set(data.map(d=>d.Indicador)); const counts={}; for(const d of data){ counts[d.Classificacao]=(counts[d.Classificacao]||0)+1; }
    const nums = data.map(d=> Number(d.Valor)).filter(x=> !Number.isNaN(x)); const media = nums.length? (nums.reduce((a,b)=>a+b,0)/nums.length): null; const min = nums.length? Math.min(*nums): null; const max = nums.length? Math.max(*nums): null;
    qsHost.appendChild(statCard('Registros (após filtro)', total)); qsHost.appendChild(statCard('Ativos distintos', ativos.size)); qsHost.appendChild(statCard('Indicadores distintos', indic.size)); qsHost.appendChild(statCard('Valor (média)', media!==null? media.toLocaleString('pt-BR', {maximumFractionDigits:4}) : '—')); qsHost.appendChild(statCard('Valor (mín.)', min!==null? min.toLocaleString('pt-BR') : '—')); qsHost.appendChild(statCard('Valor (máx.)', max!==null? max.toLocaleString('pt-BR') : '—'));
    const classes=Object.keys(counts).sort(); for(const c of classes){ qsHost.appendChild(statCard(`Qtd – ${c}`, counts[c])); }
  }
  let currentFilter='Todos';
  function render(filter='Todos'){
    currentFilter=filter; wrap.innerHTML=''; const q=by('#q').value.trim().toLowerCase(); let data=RAW; if(filter!=='Todos') data=data.filter(r=>r.Classificacao===filter); if(q) data=data.filter(r=> (r.Indicador||'').toLowerCase().includes(q) || (r.Ativo||'').toLowerCase().includes(q));
    recomputeQuickStats(data);
    for(const rec of data){ const chip=CLASS_MAP[rec.Classificacao]||'moderado'; const el=document.createElement('div'); el.className='card'; el.innerHTML = `<div class=meta>${rec.Ativo} · ${rec.Agrupador||'—'} · ${rec.Fonte||'—'}</div><h3>${rec.Indicador} <span class="chip ${chip}">${rec.Classificacao}</span></h3><div class=value>${fmtValor(rec)}</div><div class=small>Faixa: ${rec.Faixa||'—'}</div>`; wrap.appendChild(el); }
  }
  render('Todos');
}
