
from django.db import models

class IndicatorRecord(models.Model):
    Agrupador = models.CharField(max_length=120, null=True, blank=True)
    Fonte = models.CharField(max_length=120, null=True, blank=True)
    Ativo = models.CharField(max_length=40)
    Indicador = models.CharField(max_length=120)
    Formula = models.TextField(null=True, blank=True)
    Definicao = models.TextField(null=True, blank=True)
    Referencia = models.TextField(null=True, blank=True)
    Valor = models.FloatField(null=True, blank=True)
    Classificacao = models.CharField(max_length=40, null=True, blank=True)
    Faixa = models.TextField(null=True, blank=True)
    Descricao = models.TextField(null=True, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=['Ativo']),
            models.Index(fields=['Indicador']),
            models.Index(fields=['Classificacao']),
        ]

    def __str__(self):
        return f"{self.Ativo} · {self.Indicador}"
