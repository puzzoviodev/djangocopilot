
from django.core.management.base import BaseCommand, CommandError
from core.models import IndicatorRecord
from pathlib import Path
import pandas as pd

class Command(BaseCommand):
    help = 'Importa CSV/XLSX com colunas: Agrupador, Fonte, Ativo, Indicador, Formula, Definicao, Referencia, Valor, Classificacao, Faixa, Descricao.'

    def add_arguments(self, parser):
        parser.add_argument('--arquivo', required=True, help='Caminho para CSV ou XLSX')
        parser.add_argument('--sheet', default=0, help='Nome ou índice da planilha (XLSX)')
        parser.add_argument('--sep', default=',', help='Separador (CSV)')
        parser.add_argument('--encoding', default='utf-8', help='Encoding (CSV)')

    def handle(self, *args, **opts):
        path = Path(opts['arquivo'])
        if not path.exists():
            raise CommandError(f'Arquivo não encontrado: {path}')
        if path.suffix.lower() in ('.xlsx','.xlsm','.xls'):
            if path.suffix.lower()=='.xls':
                df = pd.read_excel(path, sheet_name=opts['sheet'], engine='xlrd')
            else:
                df = pd.read_excel(path, sheet_name=opts['sheet'], engine='openpyxl')
        elif path.suffix.lower() in ('.csv','.txt'):
            df = pd.read_csv(path, sep=opts['sep'], encoding=opts['encoding'])
        else:
            raise CommandError('Formato suportado: CSV ou XLSX')

        # normaliza nomes de colunas
        df.columns = [c.strip() for c in df.columns]
        # Garante todas as colunas
        required = ['Agrupador','Fonte','Ativo','Indicador','Formula','Definicao','Referencia','Valor','Classificacao','Faixa','Descricao']
        for c in required:
            if c not in df.columns:
                df[c] = None

        objs = []
        for _, row in df.iterrows():
            val = row.get('Valor', None)
            try:
                val = float(val) if val is not None and str(val).strip()!='' else None
            except:
                val = None
            objs.append(IndicatorRecord(
                Agrupador=row.get('Agrupador'),
                Fonte=row.get('Fonte'),
                Ativo=str(row.get('Ativo')) if row.get('Ativo') is not None else '',
                Indicador=str(row.get('Indicador')) if row.get('Indicador') is not None else '',
                Formula=row.get('Formula'),
                Definicao=row.get('Definicao'),
                Referencia=row.get('Referencia'),
                Valor=val,
                Classificacao=row.get('Classificacao'),
                Faixa=row.get('Faixa'),
                Descricao=row.get('Descricao'),
            ))
        IndicatorRecord.objects.all().delete()
        IndicatorRecord.objects.bulk_create(objs, batch_size=1000)
        self.stdout.write(self.style.SUCCESS(f'Importados {len(objs)} registros.'))
