
from django.contrib import admin
from .models import IndicatorRecord

@admin.register(IndicatorRecord)
class IndicatorRecordAdmin(admin.ModelAdmin):
    list_display = ('Ativo','Indicador','Classificacao','Valor','Agrupador','Fonte')
    search_fields = ('Ativo','Indicador','Classificacao','Agrupador','Fonte')
    list_filter = ('Classificacao','Agrupador','Fonte')
