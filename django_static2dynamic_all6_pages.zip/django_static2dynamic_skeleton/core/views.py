
from django.http import JsonResponse, Http404
from django.shortcuts import render
from .models import IndicatorRecord

# API que retorna todos os registros

def dataset_api(request):
    qs = IndicatorRecord.objects.all().values(
        'Agrupador','Fonte','Ativo','Indicador','Formula','Definicao','Referencia','Valor','Classificacao','Faixa','Descricao'
    )
    data = list(qs)
    return JsonResponse({'ativo_col':'Ativo','data': data}, json_dumps_params={'ensure_ascii':False})

# Página dinâmica (CSR): carrega o template pelo slug

def user_page(request, slug: str):
    template = f'user_pages/{slug}.html'
    try:
        return render(request, template)
    except Exception as e:
        raise Http404(f'Template não encontrado: {template}')
