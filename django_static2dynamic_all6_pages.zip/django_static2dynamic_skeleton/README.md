
# Django + SQLite – Cards/Heatmaps dinâmicos (StatusInvest-like)

## Como rodar
```bash
python -m venv .venv
# Windows: .venv\Scriptsctivate
# Linux/macOS: source .venv/bin/activate
pip install django pandas openpyxl xlrd
python manage.py makemigrations
python manage.py migrate
python manage.py importar_dados --arquivo dados.xlsx  # ou dados.csv
python manage.py runserver
```

## Endpoints
- API JSON: `GET /api/dataset` → `{ "ativo_col": "Ativo", "data": [...] }`
- Páginas (CSR):
  - `/page/ex2_cards_grid_from_excel/`
  - `/page/hf01_filter_togglecard/`
  - `/page/hf02_filter_button_details/`
  - `/page/hf04_filter_modal/`
  - `/page/hf07_filter_quickstats/`
  - `/page/hm01_basic/`

## Esquema da tabela
Campos: Agrupador, Fonte, Ativo, Indicador, Formula, Definicao, Referencia, Valor (float), Classificacao, Faixa, Descricao.

> Importador aceita CSV/XLSX e apaga os registros existentes antes de inserir (para facilitar refazer testes).
