
from django.contrib import admin
from django.urls import path, re_path
from core import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/dataset', views.dataset_api, name='dataset-api'),
    # CSR pages
    re_path(r'^page/(?P<slug>[-a-zA-Z0-9_]+)/$', views.user_page, name='user-page'),
]
