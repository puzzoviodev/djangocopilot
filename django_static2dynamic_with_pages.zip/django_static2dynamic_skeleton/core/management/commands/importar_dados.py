
from django.core.management.base import BaseCommand
from django.db import transaction
from core.models import IndicatorRecord

import pandas as pd
from pathlib import Path

class Command(BaseCommand):
    help = 'Importa dados de CSV/XLSX para a tabela IndicatorRecord.'

    def add_arguments(self, parser):
        parser.add_argument('--arquivo', required=True, help='Caminho do CSV ou XLSX a importar')
        parser.add_argument('--limpar', action='store_true', help='Se passado, limpa a tabela antes de importar')

    def handle(self, *args, **opts):
        caminho = Path(opts['arquivo']).resolve()
        if not caminho.exists():
            self.stderr.write(self.style.ERROR(f'Arquivo não encontrado: {caminho}'))
            return

        # Lê CSV ou XLSX
        if caminho.suffix.lower() == '.csv':
            df = pd.read_csv(caminho)
        elif caminho.suffix.lower() in ('.xlsx', '.xlsm', '.xls'):
            engine = 'openpyxl' if caminho.suffix.lower() == '.xlsx' else None
            df = pd.read_excel(caminho, engine=engine)
        else:
            self.stderr.write(self.style.ERROR('Formato não suportado. Use .csv ou .xlsx/.xlsm/.xls'))
            return

        # Normaliza nomes de colunas
        df.columns = [str(c).strip() for c in df.columns]
        if 'Definição' in df.columns and 'Definicao' not in df.columns:
            df['Definicao'] = df['Definição']
        df = df.fillna('')

        objetos = []
        for _, row in df.iterrows():
            # Converte "Valor" para número (considerando vírgula como decimal)
            valor_raw = row.get('Valor', '')
            valor_num = None
            if str(valor_raw).strip() != '':
                try:
                    valor_num = float(str(valor_raw).replace('.', '').replace(',', '.'))
                except Exception:
                    valor_num = None

            objetos.append(IndicatorRecord(
                Agrupador     = row.get('Agrupador', ''),
                Fonte         = row.get('Fonte', ''),
                Ativo         = row.get('Ativo', ''),
                Indicador     = row.get('Indicador', ''),
                Formula       = row.get('Formula', ''),
                Definicao     = row.get('Definicao', row.get('Definição', '')),
                Referencia    = row.get('Referencia', ''),
                Valor         = valor_num,
                Classificacao = row.get('Classificacao', ''),
                Faixa         = row.get('Faixa', ''),
                Descricao     = row.get('Descricao', ''),
            ))

        with transaction.atomic():
            if opts['limpar']:
                IndicatorRecord.objects.all().delete()
            IndicatorRecord.objects.bulk_create(objetos, batch_size=1000)

        self.stdout.write(self.style.SUCCESS(f'Import OK: {len(objetos)} registros'))
