
from django.contrib import admin
from .models import IndicatorRecord

@admin.register(IndicatorRecord)
class IndicatorRecordAdmin(admin.ModelAdmin):
    list_display = ('Indicador','Ativo','Valor','Classificacao','Agrupador')
    search_fields = ('Indicador','Ativo','Classificacao','Agrupador','Fonte')
