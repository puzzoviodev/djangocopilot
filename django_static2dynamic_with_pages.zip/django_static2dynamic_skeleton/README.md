
# Django (SQLite) - Skeleton para transformar HTML estático em dinâmico

Este projeto fornece uma estrutura mínima em **Django + SQLite** para hospedar seus **HTMLs estáticos** e convertê-los em **páginas dinâmicas**, consumindo dados de uma **API JSON** interna (`/api/dataset`).

## O que vem pronto
- **Banco**: SQLite (nativo), sem dependências adicionais.
- **Model**: `IndicatorRecord` cobrindo os campos: Agrupador, Fonte, Ativo, Indicador, Formula, Definicao, Referencia, Valor, Classificacao, Faixa, Descricao.
- **API**: `GET /api/dataset` devolve `{ "ativo_col": "Ativo", "data": [...] }` no exato formato que seus HTMLs podem consumir.
- **Páginas**:
  - `/page/<nome>/` tenta renderizar `templates/user_pages/<nome>.html` sem SSR (ideal para **fetch** no front).
  - `/page-ssr/<nome>/` renderiza **SSR** (injeta JSON no `<script id="dataset">`). Útil se seu HTML está esperando um `<script id="dataset">...</script>` embutido.
- **Importação**: comando `importar_dados` para popular o SQLite a partir de `CSV` ou `XLSX`.
- **Front helper**: `static/js/dataset-loader.js` que faz `fetch('/api/dataset')` e expõe `window.AT` e `window.RAW` (e chama `window.initPage()` se existir), reduzindo alterações nos HTMLs.

## Início rápido
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/Mac: source .venv/bin/activate
pip install -r requirements.txt

# migrações
python manage.py makemigrations
python manage.py migrate

# (opcional) importar dados a partir de Excel/CSV
# Coloque o arquivo na raiz do projeto. Ex.: dados.xlsx ou dados.csv
python manage.py importar_dados --arquivo dados.xlsx
# ou
python manage.py importar_dados --arquivo dados.csv

# rodar
python manage.py runserver
```

## Como usar com seus HTMLs
1. Coloque seus arquivos em `templates/user_pages/`. Ex.: `templates/user_pages/hfm01_modal_tabs.html`.
2. Acesse em `http://127.0.0.1:8000/page/hfm01_modal_tabs/` (fetch client-side) **ou** `http://127.0.0.1:8000/page-ssr/hfm01_modal_tabs/` (SSR).
3. **Opção A - fetch** (recomendado):
   - Adicione no `<head>` ou antes de fechar `<body>`:
     ```html
     {% load static %}
     <script src="{% static 'js/dataset-loader.js' %}"></script>
     <script>
       // opcional: defina initPage para rodar após o dataset chegar
       window.initPage = function(){
           // Aqui você chama suas funções de renderização existentes.
           // Você terá window.AT (nome da coluna do ativo) e window.RAW (array de registros).
       }
       loadDataset('/api/dataset'); // faz fetch e chama initPage()
     </script>
     ```
   - Mantém seu JS praticamente igual; apenas leia `window.AT` e `window.RAW`.

4. **Opção B - SSR** (sem fetch):
   - Se seu HTML espera `<script id="dataset" type="application/json">{...}</script>`, use a rota `/page-ssr/<nome>/`.
   - No template, você pode acessar a variável `dataset_json` (já embutida pelo servidor):
     ```html
     <script id="dataset" type="application/json">{{ dataset_json|safe }}</script>
     ```

## Filtros e paginação (exemplo de querystring)
`/api/dataset?indicador=P/L&ativo=PETR4&classificacao=Bom&limit=500`

Você pode estender `core/views.py` para `offset`, ordenação e outros filtros.

## Observação sobre acentos
No banco, usamos `Definicao` (sem acento) para padronizar.

## Estrutura
```
django_static2dynamic_skeleton/
  manage.py
  project/
    settings.py, urls.py, wsgi.py, asgi.py
  core/
    models.py, views.py, admin.py
    management/commands/importar_dados.py
  templates/
    user_pages/ (coloque seus HTMLs aqui)
  static/js/dataset-loader.js
  requirements.txt, README.md
```

Bom proveito!


---

## Páginas incluídas (seus HTMLs, agora dinâmicos)
- **Ex2 – Cards Grid (dinâmico)**: [/page/ex2_cards_grid_from_excel/](http://127.0.0.1:8000/page/ex2_cards_grid_from_excel/)
- **Heatmap – Toggle no cartão**: [/page/hf01_filter_togglecard/](http://127.0.0.1:8000/page/hf01_filter_togglecard/)
- **Heatmap – Botão Detalhes**: [/page/hf02_filter_button_details/](http://127.0.0.1:8000/page/hf02_filter_button_details/)

> Todas usam fetch do endpoint `/api/dataset` e respeitam os campos do banco: Agrupador, Fonte, Ativo, Indicador, Formula, Definicao, Referencia, Valor, Classificacao, Faixa, Descricao.
