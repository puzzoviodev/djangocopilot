from django.http import JsonResponse
from django.shortcuts import render
from .models import IndicadorRegistro
import json

def dataset_json(request):
    qs = IndicadorRegistro.objects.all()[:2000]
    data = list(qs.values('Agrupador','Fonte','Ativo','Indicador','Formula','Definicao','Referencia','Valor','Classificacao','Faixa','Descricao'))
    return JsonResponse({'ativo_col':'Ativo','data':data}, json_dumps_params={'ensure_ascii':False})

def page_hfm01_tabs(request):
    return render(request, 'hfm01_modal_tabs.html', {})
