from django.db import models
class IndicadorRegistro(models.Model):
    Agrupador=models.CharField(max_length=120, blank=True)
    Fonte=models.CharField(max_length=120, blank=True)
    Ativo=models.CharField(max_length=50, db_index=True)
    Indicador=models.CharField(max_length=150, db_index=True)
    Formula=models.TextField(blank=True)
    Definicao=models.TextField(blank=True)
    Referencia=models.TextField(blank=True)
    Valor=models.DecimalField(max_digits=20, decimal_places=6, null=True, blank=True)
    Classificacao=models.CharField(max_length=60, db_index=True)
    Faixa=models.CharField(max_length=200, blank=True)
    Descricao=models.TextField(blank=True)
    def __str__(self):
        return f"{self.Indicador} · {self.Ativo}"
