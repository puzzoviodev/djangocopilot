from django.contrib import admin
from django.urls import path
from indicadores.views import dataset_json, page_hfm01_tabs
urlpatterns = [
 path('admin/', admin.site.urls),
 path('api/dataset', dataset_json, name='dataset_json'),
 path('hfm01_modal_tabs/', page_hfm01_tabs, name='hfm01'),
]
